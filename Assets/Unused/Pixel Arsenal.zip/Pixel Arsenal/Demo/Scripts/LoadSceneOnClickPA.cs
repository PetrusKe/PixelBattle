﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneOnClickPA : MonoBehaviour
{
    public void LoadSceneDemo1()
    {
        SceneManager.LoadScene("demo_missiles");
    }
    public void LoadSceneDemo2()
    {
        SceneManager.LoadScene("demo_beams");
    }
    public void LoadSceneDemo3()
    {
        SceneManager.LoadScene("3");
    }
    public void LoadSceneDemo4()
    {
        SceneManager.LoadScene("4");
    }
    public void LoadSceneDemo5()
    {
        SceneManager.LoadScene("5");
    }
    public void LoadSceneDemo6()
    {
        SceneManager.LoadScene("6");
    }
    public void LoadSceneDemo7()
    {
        SceneManager.LoadScene("7");
    }
    public void LoadSceneDemo8()
    {
        SceneManager.LoadScene("8");
    }
    public void LoadSceneDemo9()
    {
        SceneManager.LoadScene("9");
    }
    public void LoadSceneDemo10()
    {
        SceneManager.LoadScene("10");
    }
}